# UI Manager


[rpcx-ui](https://github.com/smallnest/rpcx-ui)


![](https://raw.githubusercontent.com/smallnest/rpcx-ui/master/services.png)